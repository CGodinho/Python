from setuptools import setup

setup(
    name='functions',
    version='1.0',
    description='An example Python module',
    author='Carlos Godinho',
    author_email='cma.godinho@gmail.com',
    url='https://some.site.com',
    py_modules=['functions'],
)